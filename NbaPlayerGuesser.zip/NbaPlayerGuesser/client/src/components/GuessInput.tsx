import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface Player {
  id: number;
  name: string;
}

interface GuessInputProps {
  onGuess: (playerName: string) => void;
  disabled: boolean;
  remainingGuesses: number;
}

export default function GuessInput({ onGuess, disabled, remainingGuesses }: GuessInputProps) {
  const [inputValue, setInputValue] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Search players for autocomplete
  const { data: suggestions = [] } = useQuery<Player[]>({
    queryKey: ['/api/players/search', inputValue],
    queryFn: async () => {
      if (inputValue.length < 2) return [];
      const res = await fetch(`/api/players/search?q=${encodeURIComponent(inputValue)}`);
      return res.json();
    },
    enabled: inputValue.length >= 2,
  });

  const handleSubmit = () => {
    if (inputValue.trim()) {
      onGuess(inputValue.trim());
      setInputValue("");
      setShowSuggestions(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  const selectSuggestion = (playerName: string) => {
    setInputValue(playerName);
    setShowSuggestions(false);
    onGuess(playerName);
    setInputValue("");
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h3 className="text-xl font-bold text-nba-navy mb-4">Make Your Guess</h3>
      
      {/* Attempts remaining indicator */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-600">Attempts remaining:</span>
        <div className="flex space-x-2">
          {Array.from({ length: 5 }, (_, i) => (
            <div 
              key={i}
              className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                i < remainingGuesses 
                  ? 'border-nba-orange bg-nba-orange text-white' 
                  : 'border-red-500 bg-red-500 text-white'
              }`}
            >
              {i < remainingGuesses ? (
                <i className="fas fa-basketball-ball text-sm"></i>
              ) : (
                <i className="fas fa-times text-sm"></i>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Input
            type="text"
            placeholder="Enter NBA player name..."
            value={inputValue}
            onChange={(e) => {
              setInputValue(e.target.value);
              setShowSuggestions(true);
            }}
            onKeyPress={handleKeyPress}
            disabled={disabled}
            className="text-lg h-12 focus:ring-2 focus:ring-nba-orange focus:border-nba-orange"
          />
          
          {/* Autocomplete suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-b-lg shadow-lg z-10 max-h-60 overflow-y-auto">
              {suggestions.map((player) => (
                <div
                  key={player.id}
                  className="p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                  onClick={() => selectSuggestion(player.name)}
                >
                  {player.name}
                </div>
              ))}
            </div>
          )}
        </div>
        
        <Button 
          onClick={handleSubmit}
          disabled={disabled || !inputValue.trim()}
          className="px-8 h-12 bg-nba-orange hover:bg-orange-600 text-white font-semibold"
        >
          {disabled ? (
            <i className="fas fa-spinner fa-spin mr-2"></i>
          ) : (
            <i className="fas fa-paper-plane mr-2"></i>
          )}
          Guess
        </Button>
      </div>
    </div>
  );
}
