export default function GameHeader() {
  const currentDate = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  // Calculate game number based on a start date (e.g., Jan 1, 2024)
  const startDate = new Date('2024-01-01');
  const today = new Date();
  const gameNumber = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  return (
    <header className="bg-nba-navy text-white py-6 shadow-lg">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <i className="fas fa-basketball-ball text-nba-orange text-3xl"></i>
            <div>
              <h1 className="text-3xl font-bold">Stat Guess</h1>
              <p className="text-gray-300 text-sm">Daily NBA Player Challenge</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-300">Game #{gameNumber}</div>
            <div className="text-lg font-semibold">{currentDate}</div>
          </div>
        </div>
      </div>
    </header>
  );
}
