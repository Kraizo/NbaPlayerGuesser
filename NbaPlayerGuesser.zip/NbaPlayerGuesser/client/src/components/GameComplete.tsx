import { Button } from "@/components/ui/button";

interface Player {
  name: string;
  team: string;
  championships: number;
}

interface GameCompleteProps {
  won: boolean;
  correctPlayer?: Player;
  guessCount: number;
}

export default function GameComplete({ won, correctPlayer, guessCount }: GameCompleteProps) {
  if (!correctPlayer) return null;

  const handleShare = () => {
    const result = won 
      ? `🏀 Stat Guess - I got it in ${guessCount} guess${guessCount === 1 ? '' : 'es'}!`
      : `🏀 Stat Guess - I couldn't guess today's player in 5 tries!`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Stat Guess',
        text: result,
        url: window.location.href,
      });
    } else {
      navigator.clipboard?.writeText(result);
      alert('Result copied to clipboard!');
    }
  };

  return (
    <div className={`bg-white rounded-xl shadow-lg p-8 border-2 ${
      won ? 'border-green-500' : 'border-red-500'
    }`}>
      <div className="text-center">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
          won ? 'bg-green-500' : 'bg-red-500'
        }`}>
          <i className={`text-white text-3xl ${
            won ? 'fas fa-trophy' : 'fas fa-times'
          }`}></i>
        </div>
        
        <h2 className={`text-2xl font-bold mb-2 ${
          won ? 'text-green-600' : 'text-red-600'
        }`}>
          {won ? 'Congratulations!' : 'Game Over'}
        </h2>
        
        <p className="text-gray-700 mb-4">
          {won 
            ? `You correctly guessed ${correctPlayer.name} in ${guessCount} guess${guessCount === 1 ? '' : 'es'}!`
            : `The correct answer was ${correctPlayer.name}`
          }
        </p>
        
        {/* Player reveal card */}
        <div className="bg-nba-navy text-white rounded-lg p-6 mb-6">
          <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full mx-auto mb-4 flex items-center justify-center">
            <i className="fas fa-user text-4xl opacity-75"></i>
          </div>
          <h3 className="text-xl font-bold mb-2">{correctPlayer.name}</h3>
          <p className="text-gray-300">{correctPlayer.team}</p>
          <div className="mt-4 text-xs">
            <div className="text-center">
              <div className="font-bold">Championships</div>
              <div>{correctPlayer.championships}</div>
            </div>
          </div>
        </div>
        
        <div className="space-y-3">
          <Button 
            onClick={handleShare}
            className="w-full bg-nba-orange hover:bg-orange-600 text-white font-semibold"
          >
            Share Result
          </Button>
          <Button 
            variant="outline"
            className="w-full"
            onClick={() => window.location.reload()}
          >
            Come Back Tomorrow
          </Button>
        </div>
      </div>
    </div>
  );
}
