import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useState } from "react";
import { format } from "date-fns";

interface DateNavigationProps {
  currentDate: string;
  onDateChange: (date: string) => void;
}

export default function DateNavigation({ currentDate, onDateChange }: DateNavigationProps) {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const today = new Date().toISOString().split('T')[0];
  const current = new Date(currentDate);
  
  const goToPreviousDay = () => {
    const previous = new Date(current);
    previous.setDate(previous.getDate() - 1);
    onDateChange(previous.toISOString().split('T')[0]);
  };
  
  const goToNextDay = () => {
    const next = new Date(current);
    next.setDate(next.getDate() + 1);
    const nextDateString = next.toISOString().split('T')[0];
    
    // Don't allow going beyond today
    if (nextDateString <= today) {
      onDateChange(nextDateString);
    }
  };
  
  const goToToday = () => {
    onDateChange(today);
  };
  
  const handleCalendarSelect = (date: Date | undefined) => {
    if (date) {
      const selectedDate = date.toISOString().split('T')[0];
      // Don't allow selecting future dates
      if (selectedDate <= today) {
        onDateChange(selectedDate);
        setIsCalendarOpen(false);
      }
    }
  };
  
  const isToday = currentDate === today;
  const canGoNext = currentDate < today;
  
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            onClick={goToPreviousDay}
            className="flex items-center space-x-2"
          >
            <i className="fas fa-chevron-left"></i>
            <span>Previous Day</span>
          </Button>
          
          <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="flex items-center space-x-2">
                <i className="fas fa-calendar"></i>
                <span>{format(current, 'MMMM d, yyyy')}</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="center">
              <Calendar
                mode="single"
                selected={current}
                onSelect={handleCalendarSelect}
                disabled={(date) => {
                  // Disable future dates
                  return date > new Date(today);
                }}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Button
            variant="outline"
            onClick={goToNextDay}
            disabled={!canGoNext}
            className="flex items-center space-x-2"
          >
            <span>Next Day</span>
            <i className="fas fa-chevron-right"></i>
          </Button>
        </div>
        
        <div className="flex items-center space-x-4">
          {!isToday && (
            <Button
              onClick={goToToday}
              className="bg-nba-orange hover:bg-orange-600 text-white flex items-center space-x-2"
            >
              <i className="fas fa-calendar-day"></i>
              <span>Today's Challenge</span>
            </Button>
          )}
          
          {!isToday && (
            <div className="text-sm text-gray-600 bg-gray-100 px-3 py-2 rounded-lg">
              <i className="fas fa-history mr-2"></i>
              Viewing past challenge
            </div>
          )}
        </div>
      </div>
    </div>
  );
}