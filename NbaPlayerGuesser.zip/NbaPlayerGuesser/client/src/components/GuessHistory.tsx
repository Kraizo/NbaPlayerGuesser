interface GuessHistoryProps {
  guesses: string[];
  completed: boolean;
}

export default function GuessHistory({ guesses, completed }: GuessHistoryProps) {
  if (guesses.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <h3 className="text-xl font-bold text-nba-navy mb-4">Your Guesses</h3>
        <div className="text-center py-8 text-gray-500">
          <i className="fas fa-search text-4xl mb-3 text-gray-300"></i>
          <p>Your guesses will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h3 className="text-xl font-bold text-nba-navy mb-4">Your Guesses</h3>
      
      <div className="space-y-3">
        {guesses.map((guess, index) => (
          <div 
            key={index}
            className="flex items-center justify-between p-4 bg-red-50 border-l-4 border-red-400 rounded-r-lg"
          >
            <div className="flex items-center space-x-3">
              <i className="fas fa-times text-red-500"></i>
              <span className="font-medium text-gray-800">{guess}</span>
            </div>
            <span className="text-sm text-gray-600">Guess #{index + 1}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
