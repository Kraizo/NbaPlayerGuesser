interface Player {
  position: string;
  height: string;
  draftYear: number;
  championships: number;
}

interface HintSystemProps {
  hintsUnlocked: number;
  player: Player;
}

export default function HintSystem({ hintsUnlocked, player }: HintSystemProps) {
  const hints = [
    { label: "Position", value: player.position },
    { label: "Height", value: player.height },
    { label: "Draft Year", value: player.draftYear.toString() },
    { label: "Championships", value: player.championships.toString() },
  ];

  return (
    <div className="bg-gradient-to-r from-court-wood to-yellow-100 rounded-xl shadow-lg p-8 mb-8">
      <h3 className="text-xl font-bold text-nba-navy mb-4">
        <i className="fas fa-lightbulb text-yellow-500 mr-2"></i>
        Progressive Hints
      </h3>
      
      <div className="space-y-4">
        {hints.map((hint, index) => {
          const isUnlocked = hintsUnlocked > index;
          
          return (
            <div 
              key={index}
              className={`flex items-center space-x-3 p-3 bg-white rounded-lg transition-opacity ${
                isUnlocked ? 'opacity-100' : 'opacity-50'
              }`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                isUnlocked 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-300 text-gray-600'
              }`}>
                {isUnlocked ? (
                  <i className="fas fa-check text-sm"></i>
                ) : (
                  <span className="text-sm font-bold">{index + 1}</span>
                )}
              </div>
              <span className="font-medium">
                <strong>{hint.label}:</strong> {isUnlocked ? hint.value : '???'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
