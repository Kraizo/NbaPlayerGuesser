interface Player {
  position: string;
  height: string;
  team: string;
  draftYear: number;
  championships: number;
  ppg: number;
  rpg: number;
  apg: number;
  fgPercent: number;
  threePercent?: number;
  ftPercent: number;
  mpg: number;
  spg: number;
  bpg: number;


}

interface StatisticsDisplayProps {
  player: Player;
}

export default function StatisticsDisplay({ player }: StatisticsDisplayProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-nba-navy mb-6 text-center">Career Averages</h2>
      
      {/* Main stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="text-center p-4 bg-court-wood bg-opacity-10 rounded-lg">
          <div className="text-3xl font-bold text-nba-orange">{player.ppg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">PPG</div>
          <div className="text-xs text-gray-500">Points Per Game</div>
        </div>
        
        <div className="text-center p-4 bg-court-wood bg-opacity-10 rounded-lg">
          <div className="text-3xl font-bold text-nba-orange">{player.rpg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">RPG</div>
          <div className="text-xs text-gray-500">Rebounds Per Game</div>
        </div>
        
        <div className="text-center p-4 bg-court-wood bg-opacity-10 rounded-lg">
          <div className="text-3xl font-bold text-nba-orange">{player.apg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">APG</div>
          <div className="text-xs text-gray-500">Assists Per Game</div>
        </div>
        
        <div className="text-center p-4 bg-court-wood bg-opacity-10 rounded-lg">
          <div className="text-3xl font-bold text-nba-orange">{player.fgPercent.toFixed(1)}%</div>
          <div className="text-sm font-medium text-gray-600 mt-1">FG%</div>
          <div className="text-xs text-gray-500">Field Goal %</div>
        </div>
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mt-6">
        <div className="text-center p-4 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-800">{player.mpg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">MPG</div>
        </div>
        
        <div className="text-center p-4 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-800">{player.spg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">SPG</div>
        </div>
        
        <div className="text-center p-4 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-800">{player.bpg.toFixed(1)}</div>
          <div className="text-sm font-medium text-gray-600 mt-1">BPG</div>
        </div>
      </div>

      {/* Additional shooting stats */}
      <div className="grid grid-cols-2 gap-6 mt-6">
        {player.threePercent && (
          <div className="text-center p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg text-white">
            <div className="text-2xl font-bold">{player.threePercent.toFixed(1)}%</div>
            <div className="text-sm opacity-90 mt-1">3P%</div>
            <div className="text-xs opacity-75">Three Point %</div>
          </div>
        )}
        
        <div className="text-center p-4 bg-gradient-to-br from-green-500 to-green-600 rounded-lg text-white">
          <div className="text-2xl font-bold">{player.ftPercent.toFixed(1)}%</div>
          <div className="text-sm opacity-90 mt-1">FT%</div>
          <div className="text-xs opacity-75">Free Throw %</div>
        </div>
      </div>


    </div>
  );
}
