import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import GameHeader from "@/components/GameHeader";
import DateNavigation from "@/components/DateNavigation";
import StatisticsDisplay from "@/components/StatisticsDisplay";
import GuessInput from "@/components/GuessInput";
import GuessHistory from "@/components/GuessHistory";
import HintSystem from "@/components/HintSystem";
import GameComplete from "@/components/GameComplete";

interface Player {
  id: number;
  position: string;
  height: string;
  team: string;
  draftYear: number;
  championships: number;
  ppg: number;
  rpg: number;
  apg: number;
  fgPercent: number;
  threePercent?: number;
  ftPercent: number;
  mpg: number;
  spg: number;
  bpg: number;


}

interface DailyChallenge {
  date: string;
  player: Player;
}

interface GameSession {
  id: number;
  sessionId: string;
  date: string;
  playerId: number;
  guesses: string[];
  completed: boolean;
  won: boolean;
  guessCount: number;
}

interface GuessResponse {
  correct: boolean;
  gameCompleted: boolean;
  won: boolean;
  guessCount: number;
  correctPlayer?: Player & { name: string };
  session: GameSession;
}

export default function Home() {
  const [sessionId] = useState(() => 
    localStorage.getItem('nba-game-session') || 
    Math.random().toString(36).substring(7)
  );
  const [selectedDate, setSelectedDate] = useState(() => 
    new Date().toISOString().split('T')[0]
  );
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem('nba-game-session', sessionId);
  }, [sessionId]);

  // Get daily challenge for selected date
  const { data: dailyChallenge, isLoading: challengeLoading } = useQuery<DailyChallenge>({
    queryKey: ['/api/daily-challenge', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/daily-challenge?date=${selectedDate}`);
      return res.json();
    },
  });

  // Get or create game session for selected date
  const { data: gameSession, isLoading: sessionLoading } = useQuery<GameSession>({
    queryKey: ['/api/game-session', sessionId, selectedDate],
    queryFn: async () => {
      const res = await apiRequest('POST', '/api/game-session', { sessionId, date: selectedDate });
      return res.json();
    },
  });

  // Submit guess mutation
  const guessMutation = useMutation({
    mutationFn: async (playerName: string) => {
      const res = await apiRequest('POST', '/api/guess', { sessionId, playerName, date: selectedDate });
      return res.json() as Promise<GuessResponse>;
    },
    onSuccess: (data) => {
      if (data.correct) {
        toast({
          title: "Correct! 🎉",
          description: "You've guessed the player correctly!",
        });
      } else if (data.gameCompleted) {
        toast({
          title: "Game Over",
          description: `The correct answer was ${data.correctPlayer?.name}`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Incorrect",
          description: `${5 - data.guessCount} guesses remaining`,
          variant: "destructive",
        });
      }
      
      // Invalidate session to refresh game state
      queryClient.invalidateQueries({ queryKey: ['/api/game-session', sessionId] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGuess = (playerName: string) => {
    if (!gameSession?.completed) {
      guessMutation.mutate(playerName);
    }
  };

  if (challengeLoading || sessionLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-nba-orange mx-auto mb-4"></div>
          <p className="text-gray-600">Loading today's challenge...</p>
        </div>
      </div>
    );
  }

  if (!dailyChallenge || !gameSession) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Failed to load game data</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <GameHeader />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Game Instructions */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8 border-l-4 border-nba-orange">
          <h2 className="text-xl font-bold text-nba-navy mb-3">How to Play</h2>
          <p className="text-gray-700">
            Guess the NBA player based on their career averages! You have{" "}
            <span className="font-semibold text-basketball-red">5 attempts</span> to identify today's mystery player.
          </p>
        </div>

        <StatisticsDisplay player={dailyChallenge.player} />
        
        {!gameSession.completed && (
          <GuessInput 
            onGuess={handleGuess}
            disabled={guessMutation.isPending}
            remainingGuesses={5 - gameSession.guessCount}
          />
        )}
        
        <GuessHistory 
          guesses={gameSession.guesses || []}
          completed={gameSession.completed}
        />
        
        <HintSystem 
          hintsUnlocked={gameSession.guessCount}
          player={dailyChallenge.player}
        />
        
        {gameSession.completed && (
          <GameComplete 
            won={gameSession.won}
            correctPlayer={guessMutation.data?.correctPlayer}
            guessCount={gameSession.guessCount}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-nba-navy text-white py-8 mt-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <i className="fas fa-basketball-ball text-nba-orange"></i>
            <span className="font-semibold">Stat Guess</span>
          </div>
          <p className="text-gray-400 text-sm">Daily NBA player guessing game. Test your basketball knowledge!</p>
          <div className="flex justify-center space-x-6 mt-4 text-sm">
            <a href="#" className="text-gray-400 hover:text-white transition-colors">About</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Statistics</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Feedback</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
