import { pgTable, text, serial, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  position: text("position").notNull(),
  height: text("height").notNull(),
  team: text("team").notNull(),
  draftYear: integer("draft_year").notNull(),
  championships: integer("championships").default(0),
  ppg: real("ppg").notNull(),
  rpg: real("rpg").notNull(),
  apg: real("apg").notNull(),
  fgPercent: real("fg_percent").notNull(),
  threePercent: real("three_percent"),
  ftPercent: real("ft_percent").notNull(),
  mpg: real("mpg").notNull(),
  spg: real("spg").notNull(),
  bpg: real("bpg").notNull(),
});

export const dailyChallenge = pgTable("daily_challenge", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(),
  playerId: integer("player_id").notNull(),
});

export const gameSession = pgTable("game_session", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  date: text("date").notNull(),
  playerId: integer("player_id").notNull(),
  guesses: text("guesses").array().default([]),
  completed: boolean("completed").default(false),
  won: boolean("won").default(false),
  guessCount: integer("guess_count").default(0),
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
});

export const insertDailyChallengeSchema = createInsertSchema(dailyChallenge).omit({
  id: true,
});

export const insertGameSessionSchema = createInsertSchema(gameSession).omit({
  id: true,
});

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type DailyChallenge = typeof dailyChallenge.$inferSelect;
export type InsertDailyChallenge = z.infer<typeof insertDailyChallengeSchema>;
export type GameSession = typeof gameSession.$inferSelect;
export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;
