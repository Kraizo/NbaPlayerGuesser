import { 
  players, 
  dailyChallenge, 
  gameSession,
  type Player, 
  type InsertPlayer,
  type DailyChallenge,
  type InsertDailyChallenge,
  type GameSession,
  type InsertGameSession
} from "@shared/schema";

export interface IStorage {
  // Player methods
  getAllPlayers(): Promise<Player[]>;
  getPlayer(id: number): Promise<Player | undefined>;
  getPlayerByName(name: string): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  searchPlayers(query: string): Promise<Player[]>;
  
  // Daily challenge methods
  getDailyChallengeByDate(date: string): Promise<DailyChallenge | undefined>;
  createDailyChallenge(challenge: InsertDailyChallenge): Promise<DailyChallenge>;
  
  // Game session methods
  getGameSession(sessionId: string, date: string): Promise<GameSession | undefined>;
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  updateGameSession(id: number, updates: Partial<GameSession>): Promise<GameSession | undefined>;
}

export class MemStorage implements IStorage {
  private players: Map<number, Player>;
  private dailyChallenges: Map<string, DailyChallenge>;
  private gameSessions: Map<string, GameSession>;
  private currentPlayerId: number;
  private currentChallengeId: number;
  private currentSessionId: number;

  constructor() {
    this.players = new Map();
    this.dailyChallenges = new Map();
    this.gameSessions = new Map();
    this.currentPlayerId = 1;
    this.currentChallengeId = 1;
    this.currentSessionId = 1;
    
    // Initialize with some NBA players
    this.initializePlayers();
  }

  private initializePlayers() {
    const nbaPlayers: InsertPlayer[] = [
      {
        name: "LeBron James",
        position: "SF/PF",
        height: "6'9\"",
        team: "Los Angeles Lakers",
        draftYear: 2003,
        championships: 4,
        ppg: 27.2,
        rpg: 7.5,
        apg: 7.3,
        fgPercent: 50.5,
        threePercent: 34.5,
        ftPercent: 73.4,
        mpg: 38.8,
        spg: 1.6,
        bpg: 0.8,


      },
      {
        name: "Kobe Bryant",
        position: "SG",
        height: "6'6\"",
        team: "Los Angeles Lakers",
        draftYear: 1996,
        championships: 5,
        ppg: 25.0,
        rpg: 5.2,
        apg: 4.7,
        fgPercent: 44.7,
        threePercent: 32.9,
        ftPercent: 83.7,
        mpg: 36.1,
        spg: 1.4,
        bpg: 0.5,


      },
      {
        name: "Michael Jordan",
        position: "SG",
        height: "6'6\"",
        team: "Chicago Bulls",
        draftYear: 1984,
        championships: 6,
        ppg: 30.1,
        rpg: 6.2,
        apg: 5.3,
        fgPercent: 49.7,
        threePercent: 32.7,
        ftPercent: 83.5,
        mpg: 38.3,
        spg: 2.3,
        bpg: 0.8,


      },
      {
        name: "Stephen Curry",
        position: "PG",
        height: "6'2\"",
        team: "Golden State Warriors",
        draftYear: 2009,
        championships: 4,
        ppg: 24.7,
        rpg: 4.7,
        apg: 6.5,
        fgPercent: 47.3,
        threePercent: 42.6,
        ftPercent: 91.0,
        mpg: 34.5,
        spg: 1.6,
        bpg: 0.2,


      },
      {
        name: "Kevin Durant",
        position: "PF/SF",
        height: "6'10\"",
        team: "Phoenix Suns",
        draftYear: 2007,
        championships: 2,
        ppg: 27.3,
        rpg: 7.1,
        apg: 4.3,
        fgPercent: 49.6,
        threePercent: 38.4,
        ftPercent: 88.4,
        mpg: 35.0,
        spg: 1.1,
        bpg: 1.1,


      },
    ];

    nbaPlayers.forEach(player => {
      this.createPlayer(player);
    });
  }

  async getAllPlayers(): Promise<Player[]> {
    return Array.from(this.players.values());
  }

  async getPlayer(id: number): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async getPlayerByName(name: string): Promise<Player | undefined> {
    return Array.from(this.players.values()).find(
      player => player.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.currentPlayerId++;
    const player: Player = { 
      ...insertPlayer, 
      id,
      championships: insertPlayer.championships ?? 0,
      threePercent: insertPlayer.threePercent ?? null
    };
    this.players.set(id, player);
    return player;
  }

  async searchPlayers(query: string): Promise<Player[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.players.values()).filter(player =>
      player.name.toLowerCase().includes(lowerQuery)
    );
  }

  async getDailyChallengeByDate(date: string): Promise<DailyChallenge | undefined> {
    return this.dailyChallenges.get(date);
  }

  async createDailyChallenge(insertChallenge: InsertDailyChallenge): Promise<DailyChallenge> {
    const id = this.currentChallengeId++;
    const challenge: DailyChallenge = { ...insertChallenge, id };
    this.dailyChallenges.set(challenge.date, challenge);
    return challenge;
  }

  async getGameSession(sessionId: string, date: string): Promise<GameSession | undefined> {
    const key = `${sessionId}-${date}`;
    return this.gameSessions.get(key);
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const id = this.currentSessionId++;
    const session: GameSession = { 
      ...insertSession, 
      id,
      guesses: insertSession.guesses ?? null,
      completed: insertSession.completed ?? false,
      won: insertSession.won ?? false,
      guessCount: insertSession.guessCount ?? 0
    };
    const key = `${session.sessionId}-${session.date}`;
    this.gameSessions.set(key, session);
    return session;
  }

  async updateGameSession(id: number, updates: Partial<GameSession>): Promise<GameSession | undefined> {
    const session = Array.from(this.gameSessions.values()).find(s => s.id === id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    const key = `${updatedSession.sessionId}-${updatedSession.date}`;
    this.gameSessions.set(key, updatedSession);
    return updatedSession;
  }
}

export const storage = new MemStorage();
