import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameSessionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get daily challenge for a specific date
  app.get("/api/daily-challenge", async (req, res) => {
    try {
      const dateParam = req.query.date as string;
      const targetDate = dateParam || new Date().toISOString().split('T')[0];
      let dailyChallenge = await storage.getDailyChallengeByDate(targetDate);
      
      if (!dailyChallenge) {
        // Create today's challenge if it doesn't exist
        const players = await storage.getAllPlayers();
        if (players.length === 0) {
          return res.status(500).json({ message: "No players available" });
        }
        
        // Use date as seed for consistent daily selection
        const dateNum = new Date(targetDate).getTime();
        const playerIndex = dateNum % players.length;
        const selectedPlayer = players[playerIndex];
        
        dailyChallenge = await storage.createDailyChallenge({
          date: targetDate,
          playerId: selectedPlayer.id,
        });
      }
      
      const player = await storage.getPlayer(dailyChallenge.playerId);
      if (!player) {
        return res.status(404).json({ message: "Player not found" });
      }
      
      res.json({
        date: targetDate,
        player: {
          // Don't include the name - that's what they need to guess!
          id: player.id,
          position: player.position,
          height: player.height,
          team: player.team,
          draftYear: player.draftYear,
          championships: player.championships,
          ppg: player.ppg,
          rpg: player.rpg,
          apg: player.apg,
          fgPercent: player.fgPercent,
          threePercent: player.threePercent,
          ftPercent: player.ftPercent,
          mpg: player.mpg,
          spg: player.spg,
          bpg: player.bpg,


        }
      });
    } catch (error) {
      console.error("Error getting daily challenge:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Search players for autocomplete
  app.get("/api/players/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query || query.length < 2) {
        return res.json([]);
      }
      
      const players = await storage.searchPlayers(query);
      const results = players.slice(0, 10).map(player => ({
        id: player.id,
        name: player.name,
      }));
      
      res.json(results);
    } catch (error) {
      console.error("Error searching players:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get or create game session
  app.post("/api/game-session", async (req, res) => {
    try {
      const sessionSchema = z.object({
        sessionId: z.string(),
        date: z.string().optional(),
      });
      
      const { sessionId, date } = sessionSchema.parse(req.body);
      const targetDate = date || new Date().toISOString().split('T')[0];
      
      let gameSession = await storage.getGameSession(sessionId, targetDate);
      
      if (!gameSession) {
        // Get challenge for the specified date to get the player ID
        const dailyChallenge = await storage.getDailyChallengeByDate(targetDate);
        if (!dailyChallenge) {
          return res.status(404).json({ message: "No daily challenge found" });
        }
        
        gameSession = await storage.createGameSession({
          sessionId,
          date: targetDate,
          playerId: dailyChallenge.playerId,
          guesses: [],
          completed: false,
          won: false,
          guessCount: 0,
        });
      }
      
      res.json(gameSession);
    } catch (error) {
      console.error("Error with game session:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Submit a guess
  app.post("/api/guess", async (req, res) => {
    try {
      const guessSchema = z.object({
        sessionId: z.string(),
        playerName: z.string(),
        date: z.string().optional(),
      });
      
      const { sessionId, playerName, date } = guessSchema.parse(req.body);
      const targetDate = date || new Date().toISOString().split('T')[0];
      
      const gameSession = await storage.getGameSession(sessionId, targetDate);
      if (!gameSession) {
        return res.status(404).json({ message: "Game session not found" });
      }
      
      if (gameSession.completed) {
        return res.status(400).json({ message: "Game already completed" });
      }
      
      if ((gameSession.guessCount ?? 0) >= 5) {
        return res.status(400).json({ message: "Maximum guesses reached" });
      }
      
      // Get the correct player
      const correctPlayer = await storage.getPlayer(gameSession.playerId);
      if (!correctPlayer) {
        return res.status(500).json({ message: "Player not found" });
      }
      
      // Check if guess is correct
      const isCorrect = playerName.toLowerCase().trim() === correctPlayer.name.toLowerCase().trim();
      const newGuessCount = (gameSession.guessCount ?? 0) + 1;
      const newGuesses = [...(gameSession.guesses || []), playerName];
      
      const gameCompleted = isCorrect || newGuessCount >= 5;
      
      const updatedSession = await storage.updateGameSession(gameSession.id, {
        guesses: newGuesses,
        guessCount: newGuessCount,
        completed: gameCompleted,
        won: isCorrect,
      });
      
      res.json({
        correct: isCorrect,
        gameCompleted,
        won: isCorrect,
        guessCount: newGuessCount,
        correctPlayer: gameCompleted ? correctPlayer : null,
        session: updatedSession,
      });
    } catch (error) {
      console.error("Error submitting guess:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
